var searchData=
[
  ['stoprequest',['StopRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1ChannelsResource_1_1StopRequest.html',1,'Google::Apis::Drive::v2::ChannelsResource']]]
];
